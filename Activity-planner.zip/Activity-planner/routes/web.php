<?php

use App\Http\Controllers\ActivityController;
use App\Http\Controllers\CalenderController;
use App\Http\Controllers\CategoryController;
use App\Http\Controllers\PlannerController;
use App\Http\Controllers\ProfileController;
use App\Http\Controllers\PointController;
use Illuminate\Support\Facades\Route;

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider and all of them will
| be assigned to the "web" middleware group. Make something great!
|
*/

Route::get('/', function () {
    return view('welcome');
});

Route::get('/welcome', function () {
    return view('welcome');
})->name('welcome');


Route::get('/dashboard', function () {
    return view('dashboard');
})->middleware(['auth', 'verified'])->name('dashboard');

Route::get('planner', function () {
    return view('User/planner');
})->middleware(['auth', 'verified'])->name('planner');

Route::get('categories', function () {
    return view('User/categories');
})->middleware(['auth', 'verified'])->name('categories');

Route::get('activities', function () {
    return view('User/activities');
})->middleware(['auth', 'verified'])->name('activities');

Route::get('analytics', function () {
    return view('User/analytics');
})->middleware(['auth', 'verified'])->name('analytics');

Route::get('points', function () {
    return view('User/points');
})->middleware(['auth', 'verified'])->name('points');

Route::get('calenders', function () {
    return view('User/planner');
})->middleware(['auth', 'verified'])->name('calenders');

Route::post('logout', function () {
    return view('logout');
})->middleware(['auth', 'verified'])->name('logout');



Route::middleware('auth')->group(function () {
    Route::get('/profile', [ProfileController::class, 'edit'])->name('profile.edit');
    Route::patch('/profile', [ProfileController::class, 'update'])->name('profile.update');
    Route::delete('/profile', [ProfileController::class, 'destroy'])->name('profile.destroy');
});



Route::post('/categories', [CategoryController::class, 'store'])->name('categories.store');
Route::get('/categories', [CategoryController::class, 'index'])->name('categories.index');


Route::get('/activities', [ActivityController::class, 'index'])->name('activities.index');
Route::get('/activities/create', [ActivityController::class, 'create'])->name('activities.create');
Route::post('/activities', [ActivityController::class, 'store'])->name('activities.store');


Route::get('/planner', [CalenderController::class, 'index'])->name('calenders.index');
Route::get('/planner/{year}/{month}', [CalenderController::class, 'showMonth'])->name('calenders.showMonth');
Route::get('/planner/{year}/{month}/{day}', [CalenderController::class, 'showDay'])->name('calenders.showDay');
Route::post('/planner', [CalenderController::class, 'store'])->name('calenders.store');
// Route::patch('/planner', [CalenderController::class, 'update'])->name('calenders.update');
// Route::patch('/calendar/{activity}', [CalendarController::class, 'update'])->name('calender.update');



Route::get('/points', [PointController::class, 'index'])->name('points.index');
Route::patch('/points', [PointController::class, 'updatePoints'])->name('points.updatePoints');





require __DIR__.'/auth.php';
