mobiscroll.select('#single-group-select', {
    showGroupWheel: true,
    inputElement: document.getElementById('my-input'),
    touchUi: false
});