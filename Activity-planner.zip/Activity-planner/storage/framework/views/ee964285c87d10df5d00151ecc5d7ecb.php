<?php if (isset($component)) { $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54 = $component; } ?>
<?php $component = App\View\Components\AppLayout::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('app-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(App\View\Components\AppLayout::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
     <?php $__env->slot('header', null, []); ?> 
        <div class="flex justify-between items-center h-full">
            <h2 class="font-semibold text-center text-xl text-gray-800 dark:text-gray-200 leading-tight write-text">
                <span class="falling-characters">
                    <?php $__currentLoopData = str_split("Buna  ziua,  " . auth()->user()->name); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $char): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <span><?php echo e($char); ?></span>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </span>
            </h2>
            <form method="POST" action="<?php echo e(route('logout')); ?>" class="ml-auto">
                            <?php echo csrf_field(); ?>

                            <?php if (isset($component)) { $__componentOriginal71c6471fa76ce19017edc287b6f4508c = $component; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.dropdown-link','data' => ['href' => route('logout'),'onclick' => 'event.preventDefault();
                                                this.closest(\'form\').submit();']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('dropdown-link'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['href' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute(route('logout')),'onclick' => 'event.preventDefault();
                                                this.closest(\'form\').submit();']); ?>
                                <?php echo e(__('Log Out')); ?>

                             <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal71c6471fa76ce19017edc287b6f4508c)): ?>
<?php $component = $__componentOriginal71c6471fa76ce19017edc287b6f4508c; ?>
<?php unset($__componentOriginal71c6471fa76ce19017edc287b6f4508c); ?>
<?php endif; ?>
            </form>
        </div>
     <?php $__env->endSlot(); ?>
    
    <style>
        @keyframes fallIn {
            0% {
                transform: translateY(-100%);
                opacity: 0;
            }
            100% {
                transform: translateY(0);
                opacity: 1;
            }
        }

        .falling-characters span {
            display: inline-block;
            animation: fallIn 0.8s ease-in-out forwards;
            opacity: 0;
        }

        .falling-characters span:nth-child(1) {
            animation-delay: 0.4s;
        }

        .falling-characters span:nth-child(2) {
            animation-delay: 0.6s;
        }
    </style>

<html>
<head>
    <title>Meine Blade View</title>
    <style>
        /* Stil für die Unterschrift oben in der Mitte */
        .signature {
            text-align: center;
            font-size: 24px;
            margin-top: 50px;
        }
        
        /* Stil für den Satz unten */
        .greeting {
            text-align: center;
            font-size: 18px;
            margin-top: 30px;
        }

        /* Stil für den Button */
        .redirect-button {
            display: block;
            margin: 20px auto;
            padding: 10px 20px;
            background-color: #3490dc;
            color: #fff;
            border: none;
            border-radius: 5px;
            cursor: pointer;
            font-size: 16px;
        }
    </style>
</head>
<body>
        <div class="signature text-gray-800 dark:text-gray-200 text-xl">
         Cum arata planul tau astazi?
        </div>

        <div class="flex justify-center items-center flex-col mt-20"> <!-- Hier wird der Button zentriert -->
            <a href="<?php echo e(route('calenders.index')); ?>">
                <button class="glow-on-hover">
                    Planner
                </button>
            </a>
        </div>
            <style> 
                html,
                body {
                margin: 0;
                padding: 0;
                width: 100%;
                height: 100vh;
                flex-direction: row;
                justify-content: center;
                align-items: center;
                background: #000;
                }

                .glow-on-hover {
                width: 300px;
                height: 50px;
                border: none;
                outline: none;
                color: #fff;
                background: #111;
                cursor: pointer;
                position: relative;
                z-index: 0;
                border-radius: 10px;
                }

                .glow-on-hover:before {
                content: '';
                background: linear-gradient(45deg, #ff0000, #ff7300, #fffb00, #48ff00, #00ffd5, #002bff, #7a00ff, #ff00c8, #ff0000);
                position: absolute;
                top: -2px;
                left:-2px;
                background-size: 400%;
                z-index: -1;
                filter: blur(5px);
                width: calc(100% + 4px);
                height: calc(100% + 4px);
                animation: glowing 20s linear infinite;
                opacity: 0;
                transition: opacity .3s ease-in-out;
                border-radius: 10px;
                }

                .glow-on-hover:active {
                color: #000
                }

                .glow-on-hover:active:after {
                background: transparent;
                }

                .glow-on-hover:hover:before {
                opacity: 1;
                }

                .glow-on-hover:after {
                z-index: -1;
                content: '';
                position: absolute;
                width: 100%;
                height: 100%;
                background: #111;
                left: 0;
                top: 0;
                border-radius: 10px;
                }

                @keyframes glowing {
                0% { background-position: 0 0; }
                50% { background-position: 400% 0; }
                100% { background-position: 0 0; }
                }
            </style>
    </a>
</body>
</html>

 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54)): ?>
<?php $component = $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54; ?>
<?php unset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54); ?>
<?php endif; ?>
<?php /**PATH C:\Users\cocio\Desktop\xampp 2.0\proiect-laravel-2\Activity-planner\resources\views/dashboard.blade.php ENDPATH**/ ?>