<!DOCTYPE html>
<!-- Created by CodingLab |www.youtube.com/CodingLabYT-->
<html lang="en" dir="ltr">
  <head>
    <meta charset="UTF-8">
    <!--<title> Drop Down Sidebar Menu | CodingLab </title>-->
    <link rel="stylesheet" href="css/sidebar-style.css">
    <!-- Boxiocns CDN Link -->
    <link href='https://unpkg.com/boxicons@2.0.7/css/boxicons.min.css' rel='stylesheet'>
     <meta name="viewport" content="width=device-width, initial-scale=1.0">
   </head>
<body>
  <div class="sidebar close">
  <section class="home-section">
    <div class="home-content">
      <i class='bx bx-menu' ></i>
      
    </div>
  </section>
    <div class="logo-details">
      <i class='bx bxl-c-plus-plus'></i>
      <span class="logo_name">Planner</span>
    </div>
    <ul class="nav-links">
      <li>
        <a href='dashboard'>
          <i class='bx bx-grid-alt' ></i>
          <span class="link_name">Dashboard</span>
        </a>
        <ul class="sub-menu blank">
          <li><a class="link_name" href='dashboard'>Dashboard</a></li>
        </ul>
      </li>
      <li>
        <div class="iocn-link">
          <a href='categories'>
            <i class='bx bx-collection' ></i>
            <span class="link_name">Category</span>
          </a>
          <i class='bx bxs-chevron-down arrow' ></i>
        </div>
        <ul class="sub-menu">
          <li><a class="link_name" href='categories'>Category</a></li>
          <li><a href='categories.create'>Create</a></li>
        </ul>
      </li>
      <li>
        <div class="iocn-link">
          <a href='activities'>
            <i class='bx bx-collection' ></i>
            <span class="link_name">Activities</span>
          </a>
          <i class='bx bxs-chevron-down arrow' ></i>
        </div>
        <ul class="sub-menu">
          <li><a class="link_name" href='activities'>Activities</a></li>
          <li><a href='activities'>Create</a></li>
        </ul>
      </li>
      <li>
        <a href='analytics'>
          <i class='bx bx-pie-chart-alt-2' ></i>
          <span class="link_name">Analytics</span>
        </a>
        <ul class="sub-menu blank">
          <li><a class="link_name" href='analytics'>Analytics</a></li>
        </ul>
      </li>
      

    <li>
        
        <li>    <?php if (isset($component)) { $__componentOriginal71c6471fa76ce19017edc287b6f4508c = $component; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.dropdown-link','data' => ['href' => route('profile.edit')]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('dropdown-link'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['href' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute(route('profile.edit'))]); ?>
                            <i class='bx bx-cog' ></i>
                            <span class="link_name">Settings</span>
                 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal71c6471fa76ce19017edc287b6f4508c)): ?>
<?php $component = $__componentOriginal71c6471fa76ce19017edc287b6f4508c; ?>
<?php unset($__componentOriginal71c6471fa76ce19017edc287b6f4508c); ?>
<?php endif; ?> 
        </li>
    <li> 

        <ul class="sub-menu blank">
        
            <li> <?php if (isset($component)) { $__componentOriginal71c6471fa76ce19017edc287b6f4508c = $component; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.dropdown-link','data' => ['href' => route('profile.edit')]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('dropdown-link'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['href' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute(route('profile.edit'))]); ?>
                    <span class="link_name">Settings</span>
                     <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal71c6471fa76ce19017edc287b6f4508c)): ?>
<?php $component = $__componentOriginal71c6471fa76ce19017edc287b6f4508c; ?>
<?php unset($__componentOriginal71c6471fa76ce19017edc287b6f4508c); ?>
<?php endif; ?> 
            </li>
        </ul>

        
    </li>
        <div class="profile-details">
            <div class="profile-content">
                
            </div>
            <div class="name-job">
                <div class="profile_name">Edi</div>
                <div class="job">User</div>
        </div>
        <form method="post" action="<?php echo e(route ('logout')); ?>">
                                <?php echo csrf_field(); ?>

                                <?php if (isset($component)) { $__componentOriginal71c6471fa76ce19017edc287b6f4508c = $component; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.dropdown-link','data' => ['href' => route('logout'),'onclick' => 'event.preventDefault();
                                                    this.closest(\'form\').submit();']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('dropdown-link'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['href' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute(route('logout')),'onclick' => 'event.preventDefault();
                                                    this.closest(\'form\').submit();']); ?>
                                    <i class='bx bx-log-out' ></i>
                                 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal71c6471fa76ce19017edc287b6f4508c)): ?>
<?php $component = $__componentOriginal71c6471fa76ce19017edc287b6f4508c; ?>
<?php unset($__componentOriginal71c6471fa76ce19017edc287b6f4508c); ?>
<?php endif; ?>
        </div>
        </form>
  </li>
</ul>
  </div>


  <div class="calendar">

       <div class="col leftCol">
        <div class="content">
    <form method="post" action="<?php echo e(route('calenders.store')); ?>">
    <?php echo csrf_field(); ?>
    <h1 class="date"><?php echo e($selectedDayName); ?>, <?php echo e($currentMonth->format("M j")); ?><span><?php echo e($day); ?></span></h1>
    <div class="notes">
        <input type="hidden" name="year" value="<?php echo e(now()->format('Y')); ?>">
        <input type="hidden" name="month" value="<?php echo e(now()->format('M')); ?>">
        <input type="hidden" name="day" value="<?php echo e(now()->format('d')); ?>">
        
        <div>
            <select name="activity_id">
                <?php $__currentLoopData = $activities; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $activity): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <option value="<?php echo e($activity->id); ?>" class="px-6 py-4"><?php echo e($activity->text); ?></option>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </select>
        </div>
        
        <div>
            <label for="start_time">Start Time:</label>
            <input type="time" name="start_time" id="start_time" required>
        </div>
        
        <div>
            <label for="end_time">End Time:</label>
            <input type="time" name="end_time" id="end_time" required>
        </div>
        
        <button type="submit" class="addActivity animate">+</button>
</form>


    
    <ul class="activityList">
        
    </ul>
</div>
        </div>
    </div>

      <div class="col rightCol">
        <div class="content">
            <h2 class="year"><?php echo e(now()->format("Y")); ?></h2>
            <ul class="months">
                <?php for($month = 1; $month <= 12; $month++): ?>
                    <li>
                        <form method="get" action="<?php echo e(route('calenders.showMonth', ['year' => now()->format('Y'), 'month' => $month])); ?>">
                        <?php echo csrf_field(); ?>
                        <input type="hidden" name="year" value="<?php echo e(now()->format('Y')); ?>">
                        <input type="hidden" class="months" class="col rightCol" name="month" value="<?php echo e($month); ?>">
                        
                           <li><button><?php echo e(Carbon\Carbon::createFromDate(now()->format('Y'), $month, 1)->format('M')); ?></button></li>
                        
                    </form>
                    </li>
                <?php endfor; ?>
            </ul>
            <div class="clearfix"></div>
            <ul class="weekday">
              <li><a href="#" title="Mon" data-value="1" class="<?php echo e(now()->format("D") === 1 ? 'selected' : ''); ?>">Mon</a></li>
              <li><a href="#" title="Tue" data-value="2" class="<?php echo e(now()->format("D") === 2 ? 'selected' : ''); ?>">Tue</a></li>
              <li><a href="#" title="Wed" data-value="3" class="<?php echo e(now()->format("D") === 3 ? 'selected' : ''); ?>">Wed</a></li>
              <li><a href="#" title="Thu" data-value="4" class="<?php echo e(now()->format("D") === 4 ? 'selected' : ''); ?>">Thu</a></li>
              <li><a href="#" title="Fri" data-value="5" class="<?php echo e(now()->format("D") === 5 ? 'selected' : ''); ?>">Fri</a></li>
              <li><a href="#" title="Sat" data-value="6" class="<?php echo e(now()->format("D") === 6 ? 'selected' : ''); ?>">Sat</a></li>
              <li><a href="#" title="Sun" data-value="7" class="<?php echo e(now()->format("D") === 7 ? 'selected' : ''); ?>">Sun</a></li>
            </ul>

            <div class="clearfix"></div>
            <ul class="days">
    <?php for($day = 1; $day <= $daysInMonth; $day++): ?>
        <li>
           <a  href=""
                   title="<?php echo e($day); ?>"
                   data-day="<?php echo e($day); ?>"
                   data-month="<?php echo e($currentMonth->format('F')); ?>"
                   class="<?php echo e($day === now()->format('d') ? 'selected' : ''); ?>"
                   onclick="updateSelectedDate(this); return false;">
                    <?php echo e($day); ?>

                </a>
            <?php if(isset($activities[$day])): ?>
                <div class="activities">
                    
                </div>
            <?php endif; ?>
        </li>
    <?php endfor; ?>
</ul>

            <div class="clearfix"></div>
        </div>
    </div>

    <script>
    function updateSelectedDate(link) {
        const selectedDay = link.getAttribute("data-day");
        const selectedMonth = link.getAttribute("data-month");
        const span = document.querySelector(".date span");
        span.innerHTML = `${selectedMonth} ${selectedDay}`;
    }
</script>







<style>
/* not required */
*,:active{
  outline: none;
}
*{
  padding: 0px;
  margin: 0px;
}

body{
  margin: 20px;
  background-color: #EEEDE9;
  -webkit-font-smoothing: antialiased;
  text-rendering: optimizeLegibility;
  font-size: 96.5%;
  font-family: Helvetica, Arial, sans-serif;
}

input{
  font-family: Helvetica, Arial, sans-serif;
}

h1, h2, h3, h4, h5, p{
  margin-bottom: 10px;
}

p{
  line-height: 20px;
}

a{
  text-decoration: none;
  color: #FF462B;
}

.clearfix{
  clear: both;
}

.animate{
  -webkit-transition: all 0.3s ease-in-out;
  -moz-transition: all 0.3s ease-in-out;
  transition: all 0.3s ease-in-out;
}


/* required */
.calendar{
  position: absolute;
  border-radius: 4px;
  overflow: hidden;
  width: 800px;
  height: 450px;
  left: 50%;
  margin-left: -400px;
  margin-top: -225px;
  top: 50%;
  background-color: #ffffff;
  color: #333333;
}

.calendar h1, .calendar h2{
  font-weight: 300;
  font-size: 26px;
  line-height: 28px;
  text-transform: uppercase;
  margin: 0px 0px 20px 0px;
}

.calendar h1 span{
  display: block;
}

.calendar .col{
  position: relative;
  float: left;
  height: 100%;
}

.calendar .col .content{
  padding: 40px;
}

.calendar ul{
  margin: 0px;
}

.calendar ul li{
  list-style: none;
}

.calendar .leftCol{
  width: 40%;
  background-color: #F48989;
}

.calendar .noteList li{
  color: #ffffff;
  margin-bottom: 10px;
}

.calendar .notes p,
.calendar .notes input,
.calendar .noteList li{
  font-weight: 300;
  font-size: 14px;
}

.calendar .notes p{
  border-bottom: solid 1px rgba(255,255,255,0.4);
}

.calendar .notes input{
  background-color: #F48989;
  color: #ffffff;
  border: none;
  width: 200px;
}

.calendar .addNote,
.calendar .removeNote{
  float: right;
  color: rgba(255,255,255,0.4);
  font-weight: bold;
  margin-left: 20px;
}

.calendar .addNote:hover,
.calendar .removeNote:hover{
  color: #ffffff;
}

.calendar .addNote{
  font-size: 16px;
}

.calendar .leftCol h1{
  color: #ffffff;
  margin-bottom: 40px;
}

.calendar .rightCol{
  width: 60%;
}

.calendar .rightCol h2{
  color: #C7BEBE;
  text-align: right;
  margin-bottom: 70px;
}

.calendar .months li,
.calendar .weekday li,
.calendar .days li{
  float: left;
  text-transform: uppercase;
}

.calendar .months li a,
.calendar .weekday li a,
.calendar .days li a, button{
  display: block;
  color: #747978;
}

.calendar .months li a, button{
  font-size: 10px;
  color: #C7BEBE;
  text-align: center;
  width: 32px;
  margin-bottom: 20px;
}

.calendar .months li .selected, button{
  font-weight: bold;
  color: #747978;
}

.calendar .weekday li a{
  width: 55px;
  text-align: center;
  margin-bottom: 20px;
  font-size: 12px;
}

.calendar .days li{
  width: 55px;
}

.calendar .days li a{
  width: 36px;
  height: 24px;
  text-align: center;
  margin: auto auto;
  font-size: 12px;
  font-weight: bold;
  border-radius: 12px;
  margin-bottom: 10px;
  padding-top: 10px;
}


.calendar .days li a:hover{
  background-color: #EEEDE9;
}

.calendar .days li .selected{
  background-color: #F5A1A3!important;
  color: #ffffff;
}

.calendar .days li .event{
  color: #F5A1A3;
}


/* placeholder color */
::-webkit-input-placeholder {color: #ffffff; }
:-moz-placeholder {color: #ffffff; }
::-moz-placeholder {color: #ffffff; }
:-ms-input-placeholder {color: #ffffff; }</style><?php /**PATH C:\Users\cocio\Desktop\xampp 2.0\proiect-laravel-2\Activity-planner\resources\views/User/planner.blade.php ENDPATH**/ ?>