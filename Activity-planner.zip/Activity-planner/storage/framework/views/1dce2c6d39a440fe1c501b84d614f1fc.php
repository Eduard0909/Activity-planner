
<?php /**PATH C:\Users\cocio\Desktop\xampp 2.0\proiect-laravel-2\Activity-planner\resources\views/layouts/navigation.blade.php ENDPATH**/ ?>