<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class Planner extends Model
{
    use HasFactory;

    // public function activity() {
        
    //     return $this->hasMany(Activity::class);
    // }

    public function user() {
        
        return $this->hasOne(User::class);
    }

    public function category() {

        return $this->belongsToOne(User::class);
    }


}
