<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class Activity extends Model
{
    use HasFactory;

    public function user() {
        
        return $this->belongsTo(User::class);
    }

    protected $fillable = ['name', 'description', 'category_id','activity_id', 'points'];

    public function category()
    {
        return $this->belongsTo(Category::class);
    }

    public function calender()
    {
        return $this->belongsTo(Calender::class);
    }

    public function point() {
        
        return $this->hasMany(Point::class);
    }

    // public function planner() {
    //     return $this->belongsTo(Planner::class);
    // }
}
