<?php

namespace App\Http\Controllers;

use App\Models\Activity;
use App\Models\Category;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;

class ActivityController extends Controller
{
    /**
     * Display a listing of the resource.
     */
    public function index()
    {
        $categories = Category::all();
        return view('user/activities', compact('categories'));
        

    }

    public function create()
    {
        $categories = Category::all(); 
        return view('categories.create', compact('categories'));
    }

    public function store(Request $request)
    {
        
        $validatedData = $request->validate([
            'category_id' => 'required',
            'text' => 'required|unique:activities',
            'text.unique' => 'Activitatea exista deja.',
        ]);
    
        $activity = new Activity;
        $activity->user_id = auth()->user()->id;
        $activity->category_id = $validatedData['category_id'];
        $activity->text = $validatedData['text'];
        $activity->save();
    
        return redirect()->route('activities.index')->with('success', 'Aktivität erfolgreich erstellt.');
    }

    /**
     * Display the specified resource.
     */
    public function show(string $id)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     */
    public function edit(string $id)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     */
    public function update(Request $request, string $id)
    {
        //
    }

    /**
     * Remove the specified resource from storage.
     */
    public function destroy(string $id)
    {
        //
    }

}
