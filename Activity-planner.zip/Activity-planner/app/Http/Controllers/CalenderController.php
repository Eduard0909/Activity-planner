<?php

namespace App\Http\Controllers;

use App\Models\Activity;
use App\Models\Calender;
use App\Models\Category;
use Carbon\Carbon;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;

class CalenderController extends Controller
{
    /**
     * Display a listing of the resource.
     */
    public function index()
    {
        $activities = Activity::all();

        return view('User/planner', compact('activities'));
    }

    public function showMonth(Request $request,$year, $month)
    {
        $currentMonth = Carbon::create($year, $month, 1);
        $daysInMonth = $currentMonth->daysInMonth;
        $startDay = $currentMonth->startOfMonth()->dayOfWeek;
        $day = $request->input('day');
        $selectedDayName = Carbon::createFromDate($year, $month, $day)->format("D");

        $activities = Activity::all();

                        

    return view('User/planner', [
        'year' => $year,
        'month' => $month,
        'currentMonth' => $currentMonth,
        'daysInMonth' => $daysInMonth,
        'startDay' => $startDay,
        'activities' => $activities,
        'day' => $day,
        'selectedDayName' => $selectedDayName,],
        compact('currentMonth', 'daysInMonth', 'startDay'));
    }

    public function showDay($year, $month, $day)
    {
        $selectedDate = Carbon::create($year, $month, $day);

        // Hier könntest du die Aktivitäten für den ausgewählten Tag aus der Datenbank abrufen

        return view('User/planner', compact('selectedDate'));
    }
    // public function create()
    // {
    //     return view('calenders.create');
    // }

    public function store(Request $request)
    {

    
    // Validierung der Eingabedaten
    $validatedData = $request->validate([
        'year' => 'required|numeric',
        'month' => 'required|string|max:255',
        'day' => 'required|string|max:255',
        'activity_id' => 'required|numeric',
        'activity_time' => 'required|date_format:H:i',
    ]);

    // Speichern der Daten in der Datenbank
    $calendarEntry = new Calender();
    $calendarEntry->user_id = auth()->user()->id; // Annahme: Eingeloggter Benutzer
    $calendarEntry->date = "{$validatedData['year']}-{$validatedData['month']}-{$validatedData['day']}";
    $calendarEntry->start_time = $validatedData['activity_time'];
    $calendarEntry->end_time = $validatedData['activity_time']; // Du musst die end_time entsprechend festlegen
    $calendarEntry->activity_id = $validatedData['activity_id'];
    $calendarEntry->save();

    // Weiterleitung oder Rückgabe der Antwort, wie du es benötigst
    
    return redirect()->route('calenders.index')->with('success', 'Note saved successfully.');
    }

    //  public function show($year,$month)
    //  {
    //      $currentYear = Carbon::now()->year;
    //      $currentMonth = Carbon::now()->month;

    //      $selectedYear = $year ?? $currentYear;
    //      $selectedMonth = $month ?? $currentMonth;

    //      // Hier kannst du die Logik zur Anzeige der Tage des ausgewählten Monats implementieren

    //      return view('User/planner', compact('selectedYear', 'selectedMonth'));
    //  }

    // App\Http\Controllers\CalendarController.php

// public function edit(Activity $activity)
// {
//     return view('calender.edit', compact('activity'));
// }


public function update(Request $request, Activity $activity)
{
    // Validate input
    $validatedData = $request->validate([
        'note' => 'nullable|string',
        'activity_time' => 'nullable|date_format:H:i',
    ]);

    // Update the activity with the validated data
    $activity->update([
        'note' => $validatedData['note'],
        'activity_time' => $validatedData['activity_time'],
    ]);

    return redirect()->route('calendar.showMonth', ['year' => $activity->date->year, 'month' => $activity->date->month])
                     ->with('success', 'Activity updated successfully.');
}


    // public function destroy($id)
    // {
    //     $calender = Calender::findOrFail($id);
    //     $calender->delete();
    //     return redirect()->route('calenders.index')->with('success', 'Calender event deleted successfully');
    // }

    // public function showMonth($year, $month)
    // {
    //     $currentYear = Carbon::now()->year;
    //     $currentMonth = Carbon::now()->month;

    //     $selectedYear = $year ?? $currentYear;
    //     $selectedMonth = $month ?? $currentMonth;

    //     // Hier kannst du die Logik zur Anzeige der Tage des ausgewählten Monats implementieren

    //     return view('calendar.show_month', compact('selectedYear', 'selectedMonth'));
    // }
}
