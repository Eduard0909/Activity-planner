<x-app-layout>
    <x-slot name="header">
        <div class="flex justify-between items-center h-full">
            <h2 class="font-semibold text-center text-xl text-gray-800 dark:text-gray-200 leading-tight write-text">
                <span class="falling-characters">
                    @foreach (str_split("Buna  ziua,  " . auth()->user()->name) as $char)
                        <span>{{ $char }}</span>
                    @endforeach
                </span>
            </h2>
            <form method="POST" action="{{ route('logout') }}" class="ml-auto">
                            @csrf

                            <x-dropdown-link :href="route('logout')"
                                onclick="event.preventDefault();
                                                this.closest('form').submit();">
                                {{ __('Log Out') }}
                            </x-dropdown-link>
            </form>
        </div>
    </x-slot>
    
    <style>
        @keyframes fallIn {
            0% {
                transform: translateY(-100%);
                opacity: 0;
            }
            100% {
                transform: translateY(0);
                opacity: 1;
            }
        }

        .falling-characters span {
            display: inline-block;
            animation: fallIn 0.8s ease-in-out forwards;
            opacity: 0;
        }

        .falling-characters span:nth-child(1) {
            animation-delay: 0.4s;
        }

        .falling-characters span:nth-child(2) {
            animation-delay: 0.6s;
        }
    </style>

<html>
<head>
    <title>Meine Blade View</title>
    <style>
        /* Stil für die Unterschrift oben in der Mitte */
        .signature {
            text-align: center;
            font-size: 24px;
            margin-top: 50px;
        }
        
        /* Stil für den Satz unten */
        .greeting {
            text-align: center;
            font-size: 18px;
            margin-top: 30px;
        }

        /* Stil für den Button */
        .redirect-button {
            display: block;
            margin: 20px auto;
            padding: 10px 20px;
            background-color: #3490dc;
            color: #fff;
            border: none;
            border-radius: 5px;
            cursor: pointer;
            font-size: 16px;
        }
    </style>
</head>
<body>
        <div class="signature text-gray-800 dark:text-gray-200 text-xl">
         Cum arata planul tau astazi?
        </div>

        <div class="flex justify-center items-center flex-col mt-20"> <!-- Hier wird der Button zentriert -->
            <a href="{{ route('calenders.index') }}">
                <button class="glow-on-hover">
                    Planner
                </button>
            </a>
        </div>
            <style> 
                html,
                body {
                margin: 0;
                padding: 0;
                width: 100%;
                height: 100vh;
                flex-direction: row;
                justify-content: center;
                align-items: center;
                background: #000;
                }

                .glow-on-hover {
                width: 300px;
                height: 50px;
                border: none;
                outline: none;
                color: #fff;
                background: #111;
                cursor: pointer;
                position: relative;
                z-index: 0;
                border-radius: 10px;
                }

                .glow-on-hover:before {
                content: '';
                background: linear-gradient(45deg, #ff0000, #ff7300, #fffb00, #48ff00, #00ffd5, #002bff, #7a00ff, #ff00c8, #ff0000);
                position: absolute;
                top: -2px;
                left:-2px;
                background-size: 400%;
                z-index: -1;
                filter: blur(5px);
                width: calc(100% + 4px);
                height: calc(100% + 4px);
                animation: glowing 20s linear infinite;
                opacity: 0;
                transition: opacity .3s ease-in-out;
                border-radius: 10px;
                }

                .glow-on-hover:active {
                color: #000
                }

                .glow-on-hover:active:after {
                background: transparent;
                }

                .glow-on-hover:hover:before {
                opacity: 1;
                }

                .glow-on-hover:after {
                z-index: -1;
                content: '';
                position: absolute;
                width: 100%;
                height: 100%;
                background: #111;
                left: 0;
                top: 0;
                border-radius: 10px;
                }

                @keyframes glowing {
                0% { background-position: 0 0; }
                50% { background-position: 400% 0; }
                100% { background-position: 0 0; }
                }
            </style>
    </a>
</body>
</html>

</x-app-layout>
